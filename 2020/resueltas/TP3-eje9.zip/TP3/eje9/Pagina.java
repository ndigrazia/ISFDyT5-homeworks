package eje9;


public class Pagina
{
    public Pagina()
    {
    }

    //TODO Agregar atributos y getters/setters
}
