package eje9;

import java.util.Vector;

public class Navegador
{
    private Vector<Pagina> historial = new Vector<Pagina>();
    private Vector<String> direcciones = new Vector<String>();
    
    private Pagina paginaActual;
    
        
    public Navegador()
    {
    }
    
    //TODO Agregar getters/setters 
    //TODO • Agregar páginas. • Eliminar páginas. • Conocer la última página visitada. • Retornar la cantidad de páginas visitadas
    //TODO • Agregar direcciones web • Eliminar direcciones web
}
