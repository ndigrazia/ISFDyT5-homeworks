package eje7;

public class Persona
{
    private int dni;
    private String nombre;
    private String apellido;

    public Persona()
    {
    }
    
    public int getDni() {
        return this.dni;
    }
    
    public void setDni(int dni) {
        this.dni = dni;
    }

    //otros getters/setters
    //....
}
