package eje7;

public abstract class Rol
{
    public Rol()
    {
    }

    public abstract int sueldo();
}
